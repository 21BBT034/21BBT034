from modeller import *

env = Environ()
aln = Alignment(env)
mdl = Model(env, file='3grs', model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes='3grsA', atom_files='3grs.pdb')
aln.append(file='A4HSF7.ali', align_codes='A4HSF7')
aln.align2d(max_gap_length=50)
aln.write(file='A4HSF7-3grsA.ali', alignment_format='PIR')
aln.write(file='A4HSF7-3grsA.pap', alignment_format='PAP')
