from modeller import *

env = Environ()
aln = Alignment(env)
mdl = Model(env, file='1p4x', model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes='1p4xA', atom_files='1p4x.pdb')
aln.append(file='q.ali', align_codes='q')
aln.align2d(max_gap_length=50)
aln.write(file='q-1p4xA.ali', alignment_format='PIR')
aln.write(file='q-1p4xA.pap', alignment_format='PAP')
