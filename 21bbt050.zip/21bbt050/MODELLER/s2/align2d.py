from modeller import *

env = Environ()
aln = Alignment(env)
mdl = Model(env, file='1l5c', model_segment=('FIRST:A','LAST:A'))
aln.append_model(mdl, align_codes='1l5c', atom_files='1l5c.pdb')
aln.append(file='P01178.ali', align_codes='P01178')
aln.align2d(max_gap_length=50)
aln.write(file='P01178-1l5c.ali', alignment_format='PIR')
aln.write(file='P01178-1l5c.pap', alignment_format='PAP')
